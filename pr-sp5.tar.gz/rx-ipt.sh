#!/bin/bash

iptables -F
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP


INTERFACE=("virbr0" "virbr1" "virbr2" "virbr3")
AINTERFACE=("virbr1" "virbr2" "virbr3")
IINTERFACE=("virbr0")

for inter in "${AINTERFACE[@]}"; do

iptables -A INPUT -i $inter -p udp -m udp --dport 53 -j ACCEPT
iptables -A INPUT -i $inter -p tcp -m tcp --dport 53 -j ACCEPT
iptables -A INPUT -i $inter -p udp -m udp --dport 67 -j ACCEPT
iptables -A INPUT -i $inter -p tcp -m tcp --dport 67 -j ACCEPT
iptables -A FORWARD -i $inter -o $inter -j ACCEPT

 
iptables -A FORWARD -i $inter -o eno1 -j ACCEPT
iptables -A FORWARD -o $inter -i eno1 -j ACCEPT

#iptables -A OUTPUT -o $inter -j ACCEPT
iptables -A OUTPUT -o $inter -p udp -m udp --dport 68 -j ACCEPT

	
done


iptables -A INPUT  -i virbr1  -s 192.168.26.0/24 -d 192.168.26.1 -j ACCEPT
iptables -A OUTPUT -o virbr1 -s 192.168.26.1 -d 192.168.26.0/24 -j ACCEPT
iptables -A OUTPUT -o virbr1 -s 192.168.99.0/24 -d 192.168.26.0/24 -j ACCEPT
iptables -A OUTPUT -o virbr1 -s 192.168.119.0/24 -d 192.168.26.0/24 -j ACCEPT


#iptables -A FORWARD -i virbr1 -o virbr2 -m state --state RELATED,ESTABLISHED -j ACCEPT
#iptables -A FORWARD -i virbr2 -o virbr1 -j ACCEPT

#iptables -A FORWARD -i virbr2 -o virbr1 -m state --state RELATED,ESTABLISHED -j ACCEPT
#iptables -A FORWARD -i virbr1 -o virbr2 -j ACCEPT

#iptables -A FORWARD -o virbr1 -i enp0s20u6 -s 192.168.26.0/24 -j DROP
#iptables -A INPUT  -i enp0s20u6 -s 192.168.26.0/24 -j DROP


iptables -A FORWARD -i virbr1 -o virbr3 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i virbr3 -o virbr1 -j ACCEPT

iptables -A FORWARD -i virbr3 -o virbr1 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i virbr1 -o virbr3 -j ACCEPT


iptables -A FORWARD -i virbr2 -o virbr1 -p icmp  -s 192.168.99.0/24 -d 192.168.26.0/24 -j ACCEPT
iptables -A FORWARD -o virbr2 -i virbr1 -p icmp  -s 192.168.99.0/24 -d 192.168.26.0/24 -j ACCEPT


echo Task 2 Q1 

iptables -A FORWARD -i virbr2 -o virbr1 -p tcp  --dport 22 -s 192.168.99.0/24 -d 192.168.26.0/24 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A FORWARD -o virbr2 -i virbr1 -p tcp  --sport 22 -d 192.168.99.0/24 -s 192.168.26.0/24 -m state --state ESTABLISHED -j ACCEPT


echo Task 2 Q2 


IINTERFACE=("virbr0")

for inter in "${IINTERFACE[@]}"; do

iptables -A INPUT -i $inter -p udp -m udp --dport 53 -s 192.168.122.0/24 -j ACCEPT
iptables -A INPUT -i $inter -p tcp -m tcp --dport 53 -s 192.168.122.0/24 -j ACCEPT
iptables -A INPUT -i $inter -p udp -m udp --dport 67 -s 192.168.122.0/24 -j ACCEPT
iptables -A INPUT -i $inter -p tcp -m tcp --dport 67 -s 192.168.122.0/24 -j ACCEPT
iptables -A FORWARD -i $inter -o $inter -s 192.168.122.14  -j ACCEPT


iptables -A FORWARD -p tcp -m tcp -i $inter -o eno1 -s 192.168.122.25  -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A FORWARD -p tcp -m tcp -o $inter -i eno1 -d 192.168.122.25  -m state --state ESTABLISHED  -j ACCEPT


echo Task 2 Q3 
iptables -A FORWARD -p udp -m udp -i $inter -o eno1 -s 192.168.122.153  -m state --state NEW,ESTABLISHED -j  ACCEPT
iptables -A FORWARD -p udp -m udp -o $inter -i eno1 -d 192.168.122.153  -m state --state ESTABLISHED -j ACCEPT

iptables -A OUTPUT -o $inter -s 192.168.122.14 -j ACCEPT
iptables -A OUTPUT -o $inter -p udp -m udp --dport 68 -j ACCEPT


done


iptables -A FORWARD -p icmp -i eno1 -o virbr0 -j ACCEPT
iptables -A FORWARD -p icmp -o eno1 -i virbr0 -j ACCEPT


iptables -A FORWARD -p udp -m udp --dport 53 -i eno1 -o virbr0 -j ACCEPT
iptables -A FORWARD -p udp -m udp --dport 53 -o eno1 -i virbr0 -j ACCEPT


iptables -A FORWARD -i eno1 -o virbr0 -j ACCEPT
iptables -A FORWARD -o eno1 -i virbr0 -j ACCEPT
	
echo Task 2 Q4 

iptables  -I INPUT   1  -i virbr1 -s 192.168.26.25 -j LOG --log-prefix "email-init"

echo Task 2 Q5 

SPOOF_IPS="0.0.0.0/8 127.0.0.0/8 10.0.0.0/8 172.16.0.0/12  224.0.0.0/3"
 
for ip in $SPOOF_IPS
do
iptables -A INPUT  -i virbr1 -s $ip  -j DROP
iptables -A OUTPUT -o virbr1 -s $ip -d 192.168.26.1 -j DROP
done

iptables -A FORWARD -i virbr1 -s 127.0.0.1 -j DROP


echo Task 2 Q6

iptables -t filter -A OUTPUT -o virbr1   -s  192.168.26.0/24  -j LOG --log-prefix "spoof not allowed to the network"
iptables -A OUTPUT -o virbr1   -s  192.168.26.0/24  -j DROP


echo Task 2 Q7 
#iptables -t filter -A OUTPUT -o virbr1 ! -s  192.168.26.0/24  -j LOG --log-prefix "spoof not allowed"
#iptables -A OUTPUT -o virbr1  ! -s  192.168.26.0/24  -j DROP


echo Task 2 Q8
iptables -A INPUT -i virbr1 -j DROP 
iptables -A OUTPUT -o virbr1 -j DROP 
 

iptables -A INPUT -p all -i eno1 -j ACCEPT
iptables -A OUTPUT -p all -o eno1 -j ACCEPT
iptables -A FORWARD -p all -i eno1 -j ACCEPT 
iptables -A INPUT  -p icmp -j ACCEPT
iptables -A OUTPUT -p icmp -j ACCEPT

