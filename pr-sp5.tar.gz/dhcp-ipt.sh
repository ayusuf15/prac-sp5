#!/bin/bash

iptables -F
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

## ADD routes 
ip r add 192.168.99.0/24 via 192.168.26.1
ip r add 192.168.119.0/24 via 192.168.26.1

echo Task 1 Q1 

iptables -A INPUT -i ens9 -p udp -m udp --dport 67 -m mac --mac-source 52:54:00:50:01:01 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A INPUT -i ens9 -p udp -m udp --dport 67 -m mac --mac-source 52:54:00:50:01:02 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A INPUT -i ens9 -p udp -m udp --dport 67 -m mac --mac-source 52:54:00:50:01:03 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A INPUT -i ens9 -p udp -m udp --dport 67 -m mac --mac-source 52:54:00:50:01:04 -m state --state NEW,ESTABLISHED -j ACCEPT

iptables -A OUTPUT -o ens9 -p udp -m udp --dport 68 -s 192.168.26.57 -m state --state ESTABLISHED -j ACCEPT



echo Task 1 Q2
iptables -I INPUT 1  -p udp -m udp --dport 67 -m string --algo kmp --hex-string '|35 01 03|' -j LOG --log-prefix "DHCP lease Req not allowed" 
iptables -A INPUT -i ens9 -p udp -m udp --dport 67:68 -j REJECT 
iptables -A OUTPUT -o ens9 -p udp -m udp --sport 68:67 -j REJECT 

echo Task 1 Q3 
ipset -N routers iphash
ipset -A routers 192.168.26.1 
ipset -A routers 192.168.99.1 
ipset -A routers 192.168.119.1


iptables -A INPUT -m set --match-set routers src -p icmp --icmp-type 8 -d 192.168.26.57 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -m set --match-set routers dst -p icmp --icmp-type 0 -s 192.168.26.57 -m state --state ESTABLISHED -j ACCEPT

iptables -A INPUT -m set --match-set routers src -p icmp --icmp-type 0 -d 192.168.26.57 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -m set --match-set routers dst -p icmp --icmp-type 8 -s 192.168.26.57 -m state --state ESTABLISHED -j ACCEPT
 

iptables -t filter -A INPUT -m set ! --match-set routers src -p icmp --icmp-type 8 -j LOG --log-prefix "icmp echo not allowed" 
iptables -t filter -A OUTPUT -m set ! --match-set routers src -p icmp --icmp-type 0 -j LOG --log-prefix "icmp echo-reply not allowed" 

iptables -t filter -A INPUT -m set ! --match-set routers src -p icmp --icmp-type 8  -m state --state NEW -j REJECT 
iptables -t filter -A OUTPUT -m set ! --match-set routers src -p icmp --icmp-type 0 -m state --state NEW -j REJECT 

echo Task 1 Q4

iptables -A INPUT -i ens9 -m set --match-set routers src -p tcp   --dport 22 -d 192.168.26.57 -m  state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -o ens9 -m set --match-set routers dst -p tcp  --sport 22 -m state --state ESTABLISHED -j ACCEPT

echo Task 1 Q5 
iptables -I INPUT  1 -i lo -d 127.0.0.1 -s 127.0.0.1 -j ACCEPT
iptables -I OUTPUT 1 -o lo -s 127.0.0.1 -d 127.0.0.1 -j ACCEPT

echo Task 1 Q7
iptables -A INPUT -s 192.168.26.0/24 -d 192.168.26.57 -j REJECT

echo Task 1 Q6
iptables -A INPUT ! -s 192.168.26.0/24 -d 192.168.26.57 -j DROP

