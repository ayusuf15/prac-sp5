#!/bin/bash

if [[ $1 == 3 ]]; then 
hping3 -1 -c 3 192.168.26.57 -a 192.168.26.5 
fi


if [[ $1 == 4 ]]; then 
ssh prac@192.168.26.57
fi


if [[ $1 == 6 ]]; then 
hping3 -c 3 192.168.26.57 -S -p 22  -a 192.168.99.5 
fi


if [[ $1 == 7 ]]; then 
hping3 -c 3 192.168.26.57 -S -p 22 -a 192.168.26.5 
fi


